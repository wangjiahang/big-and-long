from django.db import models

# Create your models here.

class Tsmodel(models.Model):

    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=30,null=False)
    author = models.CharField(max_length=30,null=False)
    upwd = models.CharField(max_length=100)
    price = models.FloatField()
    status = models.CharField(max_length=10)






