from rest_framework import serializers
from myapp.models import Tsmodel



class DetailSerializer(serializers.ModelSerializer):

    class Meta:
        model = Tsmodel
        fields = '__all__'


